import java.util.Random;
import java.util.Scanner;


public class Main {

	
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		boolean flag = true;						//flag for every new game
		int gamesCount=0;
		int loseCount=0;
		int winCount=0;
		
		while(flag){
			
			String y = "e";           //Used the y variable to pass in order to use the String choice in my code
			String choice = Menu(y);				
			
			if (choice.equals("E")){
				System.out.println("Thanks for playing!");						//end of the game
				flag=false;
				
			}else {
				Random rand = new Random();
				int nrand = rand.nextInt(22);									//random text generator
				
				String currentWord = getWord(nrand);
				int charCount = currentWord.length();
				
				if(choice.equals("N")){
					StringBuilder guessedWord = new StringBuilder("_".repeat(currentWord.length()));
					boolean wordFound = false;
					int i=0;
					int correctGuess=0;
					int wrongGuess = 0;
					
					while(i<8 && wordFound == false ) {			
						System.out.println("The random word is now: " + guessedWord);
						System.out.println("\nYou have "+ (8-i) +" guesses left.\n");
						System.out.println("Your guess : ");
						char guess = input.next().charAt(0);
						
						if (Character.isLowerCase(guess)) {
							guess = Character.toUpperCase(guess);			//creating only uppercase letters
						}
						
						boolean correctLetter = false;							
						for(int j=0; j<charCount; j++) {							
							if(currentWord.charAt(j)== guess) {					
								System.out.println("The guess is CORRECT!");   //checking if the letter is correct
								guessedWord.setCharAt(j, guess);				
								correctGuess++;									
								correctLetter = true;
							}										
						}
						
						
						if (correctLetter == false) {
							System.out.println("There are no " + guess + "'s in the word.");	//checking if the letter is wrong
							wrongGuess++;
						}else {
							correctLetter = false;            									//if the letter is indeed correct I need the variable 'correctLetter' set to false for the next letter
						}
						
						if(guessedWord.toString().equals(currentWord)) {
							System.out.println("Congratulations! You guessed the word: "+currentWord);
							System.out.println("You made "+correctGuess+" correct guesses and "+wrongGuess+" wrong guesses.");		//Found the word
							wordFound = true;
							winCount++;
							break;
						}
						
						if(wordFound == false && i==7) {
							System.out.println("You don't have any more attempts. The word was :" + currentWord);					//Word not found
							loseCount++;
						}
						
						i++;								
					}
					gamesCount++;
				}else if(choice.equals("S")) {
					System.out.println("You have played so far " +gamesCount+ " games. You won "+winCount+" times and lost "+loseCount+" times. ");		//printing Statistics
				}
				
			}
			
		}
		
	}

	
	public static String getWord(int index) {
		switch (index) {
			case 0: return "UNIVERSITY";
			case 1: return "COMPUTER";
			case 2: return "LAPTOP";
			case 3: return "HEADPHONES";
			case 4: return "FUZZY";
			case 5: return "DOG";
			case 6: return "KEYHOLE";
			case 7: return "TELEPHONE";
			case 8: return "PRINTER";
			case 9: return "BUILDING";
			case 10: return "CAT";
			case 11: return "SNAKE";
			case 12: return "LIZARD";
			case 13: return "LION";
			case 14: return "WORLD";
			case 15: return "POISON";
			case 16: return "HEART";
			case 17: return "EVERYBODY";
			case 18: return "HEAD";
			case 19: return "PLANE";
			case 20: return "PACKAGE";
			case 21: return "GRAPHICS";
			default: return "Illegal index";
		}
	}

	public static String Menu(String x) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("MAIN MENU\r\n"
				+ "- Start a new Game (N)\r\n"
				+ "- Statistics (S)\r\n"
				+ "- Exit (E)\r\n"
				+ "Please enter your choice: ");
		boolean flag = true;
		while(flag){
			x = input.nextLine();
			if (x.matches("^[a-zA-Z]+$")) {
				
				flag = false;
			}else {
				System.out.println("Please provide only letters");
			}
		}
		return x.toUpperCase();
	}

}